import { FETCH_CUSTOMERS, ADD_CUSTOMER, EDIT_CUSTOMER, DELETE_CUSTOMER, EDIT_MODE, FETCH_CUSTOMER_BY_ID, ADD_CUSTOMER_BUTTON_CLICKED } from './actionTypes';



export const fetchCustomers = () => ({
    type: FETCH_CUSTOMERS
});

export const fetchCustomerById = (id) => (
    {
        type: FETCH_CUSTOMER_BY_ID,
        payload: id
    }
)


export const addCustomer = (customer) =>
(
    {
        type: ADD_CUSTOMER,
        payload: customer
    }
)

export const editCustomer = (customer) =>
(
    {

        type: EDIT_CUSTOMER,
        payload: customer

    })

export const deleteCustomer = (customerId) =>
(
    {
        type: DELETE_CUSTOMER,
        payload: customerId
    }
)

export const editMode = () =>
(
    {
        type: EDIT_MODE
    }
)

export const addCustomerBtnClicked = () =>
(
    {
        type: ADD_CUSTOMER_BUTTON_CLICKED
    }
)