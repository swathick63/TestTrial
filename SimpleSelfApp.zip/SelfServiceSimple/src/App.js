import React from 'react';
import Customer from './components/Customer';
import '../src/App.css';

function App() {
  return (
    <div className="App">
      <Customer />
    </div>
  );
}

export default App;