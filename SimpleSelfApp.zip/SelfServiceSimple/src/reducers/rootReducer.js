import { combineReducers } from 'redux';
import customerReducer from './customerReducers';

export default combineReducers({
    customerReducer
})