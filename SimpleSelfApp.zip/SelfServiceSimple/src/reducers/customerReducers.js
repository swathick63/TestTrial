import {
  FETCH_CUSTOMERS_ASYNC,
  EDIT_MODE,
  FETCH_CUSTOMER_BY_ID,
  CLEAR_STATE,
  ADD_CUSTOMER_ASYNC,
  EDIT_CUSTOMER_ASYNC,
  DELETE_CUSTOMER_ASYNC,
  FETCH_CUSTOMERS_ASYNC_ERROR,
  EDITED,
  ADD_CUSTOMER_BUTTON_CLICKED
} from "../actions/actionTypes";

const initialState = {
  customers: [],
  customer: {},
  editMode: false,
  error: false,
  isSaveBtnClicked: false,
  isEditBtnClicked: false,
  edit: false
};

export default function (state = initialState, action) {
  switch (action.type) {
    case FETCH_CUSTOMERS_ASYNC:
      return {
        ...state,
        customers: action.payload
      };
    case FETCH_CUSTOMERS_ASYNC_ERROR:
      return {
        ...state,
        error: true
      };
    case ADD_CUSTOMER_ASYNC: {

      return {
        ...state,
        customers: state.customers.concat([action.payload]),
        edit: false
      };
    }
    case DELETE_CUSTOMER_ASYNC:
      return {
        ...state,
        customers: state.customers.filter(customer => customer.id !== action.payload),
        edit: false
      };

    case EDIT_MODE:
      return {
        ...state,
        isEditBtnClicked: true
      };
    case FETCH_CUSTOMER_BY_ID: {
      return {
        ...state,
        customer: state.customers.find(usr => usr.id === action.payload)
      };
    }
    case EDIT_CUSTOMER_ASYNC:
      return {
        ...state,
        customer: action.payload,
        isEditBtnClicked: false,
        edit: true
      };
    case EDITED:
      return {
        ...state,
        edit: true
      };
    case ADD_CUSTOMER_BUTTON_CLICKED:
      return {
        ...state,
        edit: false
      };
    default:
      return state;
  }
}
