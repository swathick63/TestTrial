import React from "react";
import { connect } from "react-redux";
import { editCustomer } from "../actions/customerActions";
import Customer from "./Customer";

class CustomerEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      gender: "",
      address: ""
    };
  }

  componentDidMount() {
    let customer = this.props.customer;
    this.setState({
      id: customer.id,
      firstName: customer.firstName,
      lastName: customer.lastName,
      email: customer.email,
      phone: customer.phone,
      gender: customer.gender,
      address: customer.address
    });
  }

  onSubmit = e => {
    e.preventDefault();

    const id = this.state.id;
    const firstName = this.state.firstName;
    const lastName = this.state.lastName;
    const email = this.state.email;
    const phone = this.state.phone;
    const gender = this.state.gender;
    const address = this.state.addres;


    const customer = {
      id,
      firstName,
      lastName,
      email,
      phone,
      gender,
      address
    };
    this.props.editCustomer(customer);
  };

  render() {
    return (
      <div className="container">
        <h3>Edit </h3>
        <form onSubmit={this.onSubmit} className="form">
          <div className="form-group">
            <label> First Name </label>
            <input
              required
              type="text"
              className="form-control"
              value={this.state.firstName}
              onChange={e => {
                this.setState({ firstName: e.target.value });
              }}
            />
          </div>

          <div className="form-group">
            <label> Last Name </label>
            <input
              required
              type="text"
              className="form-control"
              value={this.state.lastName}
              onChange={e => {
                this.setState({ lastName: e.target.value });
              }}
            />
          </div>
          <div className="form-group">
            <label> Email </label>
            <input
              required
              type="email"
              className="form-control"
              value={this.state.email}
              onChange={e => {
                this.setState({ email: e.target.value });
              }}
            />
          </div>


          <div className="form-group">
            <label>phone</label>
            <br />
            <input
              required
              className="form-control-sm"
              id="gender"
              type="number"
              value={this.state.phone}
              onChange={e => {
                this.setState({ email: e.target.value });
              }}
            />
          </div>
          <div className="form-group">
            <label>Gender</label>
            <br />
            <input type="radio" id="male" name="gender" value="Male"
              onChange={e => {
                this.setState({ gender: e.target.value });
              }}></input>
            <label for="html">Male</label><br></br>
            <input type="radio" id="female" name="gender" value="Female" onChange={e => {
              this.setState({ gender: e.target.value });
            }}></input>
            <label for="html">Female</label><br></br>

          </div>
          <div className="form-group">
            <label>Address</label>
            <br />
            <input
              required
              className="form-control-sm"
              id="address"
              type="text"
              value={this.state.address}
              onChange={e => {
                this.setState({ address: e.target.value });
              }}
            />
          </div>


          <button className="btn btn-primary">Edit</button>
        </form>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  customer: state.customerReducer.customer
});

export default connect(
  mapStateToProps,
  { editCustomer }
)(CustomerEdit);
