import React from "react";
import { connect } from "react-redux";
import {
  fetchCustomers,
  deleteCustomer,
  editMode,
  fetchCustomerById
} from "../actions/customerActions";
import "../../src/App.css";

class CustomerList extends React.Component {
  componentDidMount() {
    this.props.fetchCustomers();
  }

  onEdit = customerId => {
    this.props.editMode();
    this.props.fetchCustomerById(customerId);
  };

  onDelete = customerId => {
    this.props.deleteCustomer(customerId);
  };

  render() {
    return (
      <div className="App">
        <table>
          <tbody>
            {this.props.Customers.map(u => (
              <tr key={u.id}>
                <td>{u.firstName}</td>
                <td>{u.lastName}</td>
                <td>{u.email}</td>
                <td>{u.phone}</td>
                <td>{u.gender}</td>

                <td>
                  <button onClick={() => this.onEdit(u.id)}>Edit</button>
                </td>
                <td>
                  <button onClick={() => this.onDelete(u.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  Customers: state.customerReducer.customers,
  error: state.customerReducer.error
});

export default connect(
  mapStateToProps,
  { fetchCustomers, deleteCustomer, editMode, fetchCustomerById }
)(CustomerList);
