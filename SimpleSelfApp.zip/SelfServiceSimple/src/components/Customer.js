import React from "react";
import CustomerList from "./CustomerList";
import CustomerForm from "./CustomerForm";
import CustomerEdit from "./CustomerEdit";
import { connect } from "react-redux";
import { addCustomerBtnClicked } from "../actions/customerActions";

class Customer extends React.Component {
  constructor(props) {
    super(props);

    this.state = { isSaveBtnClicked: false };
    this.state = { isEditBtnClicked: false };

    this.onClick = this.onClick.bind(this);
    this.onEditClick = this.onEditClick.bind(this);

    this.AddCustomer = this.AddCustomer.bind(this);
    this.Edit = this.Edit.bind(this);
  }

  AddCustomer() {
    this.setState({ isSaveBtnClicked: false });
  }

  Edit() {
    this.setState({ isEditBtnClicked: false });
  }

  onClick(e) {
    const isSaveBtnClicked = true;
    this.setState({ isSaveBtnClicked });
    this.props.addCustomerBtnClicked();
  }

  onEditClick(e) {
    const isEditBtnClicked = true;
    this.setState({ isEditBtnClicked });
    this.props.addCustomerBtnClicked();
  }
  render() {
    return (
      <div>
        <h2>Self Service Application</h2>
        {this.props.edit === true && (
          <h3 className="alert alert-success">Data Edited Successfully</h3>
        )}
        <div class="button">
          {this.state.isSaveBtnClicked === false ||
            this.props.isEditBtnClicked === false && (
              <button className="button btn btn-primary" style={{ 'margin-right': '16px' }} onClick={this.onClick}>
                Add Customer
              </button>
            )}
          {this.state.isSaveBtnClicked === false ||
            this.props.isEditBtnClicked === false && (
              <button className="button btn btn-primary" style={{ 'margin-right': '16px' }} onClick={this.onEditClick}>
                Edit Customer
              </button>
            )}
        </div>
        <br />
        <br />
        {this.state.isSaveBtnClicked === true && (
          <CustomerForm AddCustomerClicked={this.AddCustomer} />
        )}
        {this.state.isSaveBtnClicked === false &&
          this.props.isEditBtnClicked === true && (
            <CustomerList EditClicked={this.editBtn} />
          )}
        {this.props.isEditBtnClicked && <CustomerEdit />}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  isEditBtnClicked: state.customerReducer.isEditBtnClicked,
  edit: state.customerReducer.edit
});

export default connect(
  mapStateToProps,
  { addCustomerBtnClicked }
)(Customer);
