import React from "react";
import { connect } from "react-redux";
import { addCustomer } from "../actions/customerActions";
import "bootstrap/dist/css/bootstrap.css";

class CustomerForm extends React.Component {
  onSubmit = e => {
    e.preventDefault();
    const firstName = this.getFirstName.value;
    const lastName = this.getLastName.value;

    const email = this.getEmail.value;
    const phone = this.getPhone.value;
    const gender = this.getGender.value;
    const address = this.getAddress.value;

    const customer = { firstName: firstName, lastName: lastName, email: email, phone: phone, gender: gender, address: address };

    this.props.addCustomer(customer);
    // this.props.AddClicked();
  };

  render() {
    return (
      <div>
        <h3>Add New Customer</h3>
        <br />
        <div className="container">
          <form onSubmit={this.onSubmit} className="form">
            <div className="form-group">
              <label>First Name</label>
              <br />
              <input
                required
                className="form-control-sm"
                id="firstName"
                type="text"
                ref={input => (this.getFirstName = input)}
              />
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <br />
              <input
                required
                className="form-control-sm"
                id="lastName"
                type="text"
                ref={input => (this.getLastName = input)}
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <br />
              <input
                required
                className="form-control-sm"
                id="email"
                type="text"
                ref={input => (this.getEmail = input)}
              />
            </div>
            <div className="form-group">
              <label>phone</label>
              <br />
              <input
                required
                className="form-control-sm"
                id="firstName"
                type="number"
                ref={input => (this.getPhone = input)}
              />
            </div>
            <div className="form-group">
              <label>Gender</label>
              <br />
              <input type="radio" id="male" name="gender" value="Male" ref={input => (this.getGender = input)}></input>
              <label for="html">Male</label><br></br>
              <input type="radio" id="female" name="gender" value="Female" ref={input => (this.getGender = input)}></input>
              <label for="html">Female</label><br></br>

            </div>
            <div className="form-group">
              <label>Address</label>
              <br />
              <input
                required
                className="form-control-sm"
                id="address"
                type="text"
                ref={input => (this.getAddress = input)}
              />
            </div>
            <button className="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    );
  }
}

export default connect(
  null,
  { addCustomer }
)(CustomerForm);
