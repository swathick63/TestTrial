import axios from "axios";

export const fetchCustomers = () => {
  return axios.request({
    method: "get",
    headers: {
      "Content-Type": "application/json"
    },

    url: "https://localhost:3000/api/customers"
  });
};
