import {
  takeEvery,
  call,
  put
} from "redux-saga/effects";
import axios from "axios";
import {
  FETCH_CUSTOMERS,
  FETCH_CUSTOMERS_ASYNC,
  ADD_CUSTOMER,
  ADD_CUSTOMER_ASYNC,
  EDIT_CUSTOMER,
  DELETE_CUSTOMER,
  DELETE_CUSTOMER_ASYNC,
  EDIT_CUSTOMER_ASYNC
} from "../actions/actionTypes";
import { fetchCustomers } from "./api";

export default function* rootWatcher() {
  yield takeEvery(FETCH_CUSTOMERS, fetchCustomersAsync);
  yield takeEvery(ADD_CUSTOMER, addCustomerAsync);
  yield takeEvery(EDIT_CUSTOMER, editCustomerAsync);
  yield takeEvery(DELETE_CUSTOMER, deleteCustomerAsync);
}

export function* fetchCustomersAsync() {
  let response = yield call(fetchCustomers);
  yield put({ type: FETCH_CUSTOMERS_ASYNC, payload: response.data });
}

export function* addCustomerAsync(action) {
  yield axios.post(`https://localhost:3000/api/customers`, {
    email: action.payload.email,
    firstName: action.payload.firstName,
    lastName: action.payload.lastName
  });

  yield put({ type: ADD_CUSTOMER_ASYNC, payload: action.payload });
}

export function* editCustomerAsync(action) {
  axios.put(
    `https://localhost:3000/api/customers/` + action.payload.iD,
    action.payload
  );
  yield put({ type: EDIT_CUSTOMER_ASYNC, payload: action.payload });
  const data = yield call(fetchCustomers);
  yield put({ type: FETCH_CUSTOMERS_ASYNC, payload: data.data });
}

export function* deleteCustomerAsync(action) {
  axios.delete("https://localhost:3000/api/customers/" + action.payload);
  yield put({ type: DELETE_CUSTOMER_ASYNC, payload: action.payload });
}
